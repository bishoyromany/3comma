<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title><?php echo e(isset($page_title) ? $page_title : "BotPump"); ?></title>
    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
    <link rel="icon" type="image/png" href="<?php echo e(asset('img/favicon-white.png')); ?>?v=2111">

    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/font-awesome/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/ionicons/ionicons.min.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap-slider/slider.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('css/datatables.net-bs/dataTables.bootstrap.min.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('css/select2/select2.min.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap-daterangepicker/daterangepicker.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('css/highcharts/highcharts.css')); ?>">

    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo e(asset('css/adminlte/AdminLTE.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/adminlte/skins/_all-skins.min.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('css/w3.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('css/custom.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('css/loading.css')); ?>">

    <?php echo $__env->yieldContent('stylesheet'); ?>

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->
</head>
<body class="hold-transition skin-blue sidebar-mini">
    <div class="wrapper">
        <!-- Header -->
        <?php echo $__env->make('partials.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <!-- Sidebar -->
        <?php echo $__env->make('partials.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <!-- Content Wrapper. Contains page content -->
            <div class="content-wrapper">
                <!-- Content Header (Page header) -->
                <section class="content-header">
                    <?php
                        $segments = Request::segments();
                    ?>
                   <!--h1>
                        <?php echo e(ucwords($segments[0])); ?>

                        <small></small>
                    </h1>
                    <ol class="breadcrumb">
                        <?php for($i = 0; $i < sizeof($segments); $i++): ?>
                            <?php if($i == 0): ?>
                                <li><i class="fa fa-dashboard"></i> <?php echo e(ucwords($segments[$i])); ?></li>
                            <?php elseif($i == sizeof($segments)): ?>
                                <li class="active"><?php echo e(ucwords($segments[$i])); ?></li>
                            <?php else: ?>
                                <li><?php echo e(ucwords($segments[$i])); ?></li>
                            <?php endif; ?>
                        <?php endfor; ?>
                    </ol-->
                </section>

                <!-- Main content -->
                <section class="content">
                    <!-- Your Page Content Here -->
                    <?php echo $__env->yieldContent('content'); ?>
                </section><!-- /.content -->
            </div><!-- /.content-wrapper -->

            <!-- Footer -->
            <?php echo $__env->make('partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    </div><!-- ./wrapper -->

    <script src="<?php echo e(asset('js/jquery/jquery.min.js')); ?>"></script>

    <script src="<?php echo e(asset('js/bootstrap/bootstrap.min.js')); ?>"></script>

    <script src="<?php echo e(asset('js/datatables.net/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/datatables.net-bs/dataTables.bootstrap.min.js')); ?>"></script>

    <script src="<?php echo e(asset('js/moment/moment.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap-daterangepicker/daterangepicker.js')); ?>"></script>

    <script src="<?php echo e(asset('js/highcharts/highcharts.js')); ?>"></script>

    <script src="<?php echo e(asset('js/select2/select2.min.js')); ?>"></script>

    <script src="<?php echo e(asset('js/jquery-slimscroll/jquery.slimscroll.min.js')); ?>"></script>

    <script src="<?php echo e(asset('js/adminlte/adminlte.min.js')); ?>"></script>

    <script src="<?php echo e(asset('js/bootstrap-slider/bootstrap-slider.js')); ?>"></script>

    <script src="<?php echo e(asset('js/loading.js')); ?>"></script>

    <?php echo $__env->yieldContent('script'); ?>

</body>
</html>