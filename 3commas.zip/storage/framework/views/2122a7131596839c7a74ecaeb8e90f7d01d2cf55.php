<?php $__env->startSection('content'); ?>
<div class="box box-primary">
  <div class="box-header">
    <h3 class="box-title">Active Deals</h3>
  </div>
  <div class="box-body table-responsive no-padding">
  <table class="table table-bordered table-striped">
    <thead>
      <tr>
        <th>ID</th>
        <th>Bot</th>
        <th colspan="2">Pair</th>
        <th>Started</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $active_deals_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $active): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><a href="<?php echo e(route('basic.deal.show', $active->id )); ?>" class="label label-primary" title="Show Deal"><?php echo e($active->id); ?></a></td>
          <td><a href="<?php echo e(route('basic.bot.show', $active->bot_id )); ?>" class="label label-primary" title="Show Bot"><?php echo e($active->bot_name); ?></a></td>
          <td><span style="float: right;"><span class="label bg-gray"><?php echo e($active->from_currency); ?></span><img src="<?php echo e(asset('img/coins/' . strtolower($active->from_currency) . '.png')); ?>" height="22px"></span></td>
          <td><img src="<?php echo e(asset('img/coins/' . strtolower($active->to_currency) . '.png')); ?>" height="22px"><span class="label bg-gray"><?php echo e($active->to_currency); ?></span></td>
          <td><?php echo e($active->created_at); ?></td>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
  </div>
</div>

<div class="box box-success">
  <div class="box-header">
  <h3 class="box-title">All Deals</h3>
  </div>
  <div class="box-body table-responsive no-padding">
  <table class="table table-bordered table-striped">
    <thead>
      <tr>
        <th>ID/Bot</th>
        <th colspan="2">Pair</th>
        <th>Status</th>
        <th>Profit</th>
        <th>Profit</th>
        <th>Closed</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $all_completed_deals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $completed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td>
            <a href="<?php echo e(route('basic.deal.show', $completed->id )); ?>" class="label bg-gray" title="Show Deal">ID: <?php echo e($completed->id); ?></a><br>
            <a href="<?php echo e(route('basic.bot.show', $active->bot_id )); ?>" class="label bg-gray" title="Show Bot"><?php echo e($active->bot_name); ?></a>
          </td>
          <td><span style="float: right;"><span class="label bg-gray"><?php echo e($completed->from_currency); ?></span><img src="<?php echo e(asset('img/coins/' . strtolower($completed->from_currency) . '.png')); ?>" height="22px"></span></td>
          <td><img src="<?php echo e(asset('img/coins/' . strtolower($completed->to_currency) . '.png')); ?>" height="22px"><span class="label bg-gray"><?php echo e($completed->to_currency); ?></span></td>
          <td><?php echo e($completed->status); ?></td>
          <td><?php echo e($completed->final_profit); ?></td>
          <td>$<?php echo e($completed->usd_final_profit); ?></td>
          <td><?php echo e($completed->closed_at); ?></td>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>