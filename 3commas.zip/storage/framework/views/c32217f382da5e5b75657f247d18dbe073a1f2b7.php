<?php $__env->startSection('content'); ?>
<div class="box box-primary">
  <div class="box-header">
    <h3 class="box-title">Exchange Key APIs</h3>
    <a disabled href="#" class="btn btn-sm btn-flat btn-success pull-right">New API Key</a>
  </div>
  <div class="box-body table-responsive no-padding">
    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>API Name</th>
                <th>API Type</th>
                <th>API Key</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $exchange_keys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exchange_key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($exchange_key['name']); ?></td>
                    <td>Binance</td>
                    <td><?php echo e($exchange_key['api_key']); ?></td>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>