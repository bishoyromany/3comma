<header class="main-header">

    <a href="<?php echo e(url('dashboard')); ?>" class="logo">
        <span class="logo-mini"><img src="<?php echo e(asset('img/logoicon.jpg')); ?>" height="36px"></span>
        <span class="logo-lg"><img src="<?php echo e(asset('img/logo-black.jpg')); ?>" height="36px"></span>
    </a>

    <nav class="navbar navbar-static-top">
        <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
            <span class="sr-only">Toggle navigation</span>
        </a>
        <div class="navbar-custom-menu">
            <ul class="nav navbar-nav">
                <li class="dropdown user user-menu">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                        <?php if(!Auth::user()->avatar): ?>
                        <img src="<?php echo e(asset('/img/user-160x160.jpg')); ?>" class="user-image" alt="User Image">
                        <?php else: ?>
                        <img src="<?php echo e(asset('/storage/avatars/' . Auth::user()->avatar . '')); ?>" class="user-image" alt="User Image">
                        <?php endif; ?>
                        <span class="hidden-xs"><?php echo e(Auth::user()->name); ?></span>
                    </a>
                    <ul class="dropdown-menu">
                        <ul class="sidebar-menu">
                            <li><a href="<?php echo e(url('apikey')); ?>"><i class="fa fa-key"></i>Bot Service APIs</a></li>
                            <li><a href="<?php echo e(url('exchangekey')); ?>"><i class="fa fa-key"></i>Exchange APIs</a></li>
                            <li><a href="<?php echo e(url('profile')); ?>"><i class="fa fa-user"></i>Profile Settings</a></li>
                            <hr style="margin:0px;">
                            <li><a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><i class="fa fa-sign-out"></i>Log Out</a></li>
                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                <?php echo e(csrf_field()); ?>

                            </form>
                        </ul>
                    </ul>
                </li>
            </ul>
        </div>

    </nav>
</header>