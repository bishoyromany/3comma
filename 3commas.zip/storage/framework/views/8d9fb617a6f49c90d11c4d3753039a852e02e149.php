<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-md-5 col-md-offset-1">
    <div class="box box-primary">
      <div class="box-body box-profile">
        <?php if(!Auth::user()->avatar): ?>
        <img src="<?php echo e(asset('/img/user-160x160.jpg')); ?>" class="profile-user-img img-responsive img-circle" style="width:150px; height:150px">
        <?php else: ?>
        <img src="<?php echo e(asset('/storage/avatars/' . Auth::user()->avatar . '')); ?>" class="profile-user-img img-responsive img-circle" style="width:150px; height:150px">
        <?php endif; ?>
        <h3 class="profile-username text-center"><?php echo e($user->name); ?></h3>
        <p class="text-muted text-center">Tester</p>
        <form action="/profile" method="post" enctype="multipart/form-data">
        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
        <div class="form-group">
            <input type="file" class="form-control-file" name="avatar" id="avatarFile" aria-describedby="fileHelp">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div style="color: red;"><?php echo e($error); ?></div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <small id="fileHelp" class="form-text text-muted">Size of image should not be more than 2MB.</small>
        </div>
        <button type="submit" class="btn btn-primary btn-block">Submit</button>
        </form>
      </div>
    </div>
  </div>
  <div class="col-md-5">
    <div class="box box-primary">
      <div class="box-header with-border">
        <h3 class="box-title">Profile</h3>
      </div>
      <div class="box-body">
        <strong><i class="fa fa-user margin-r-5"></i> <?php echo e($user->name); ?></strong>

        <hr>

        <strong><i class="fa fa-envelope margin-r-5"></i> <?php echo e($user->email); ?></strong>

        <hr>

        <strong><i class="fa fa-calendar margin-r-5"></i> Created: <?php echo e(date( "F j, Y", strtotime($user->created_at))); ?></strong>

      </div>
      <!-- /.box-body -->
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>