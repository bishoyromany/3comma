<?php $__env->startSection('content'); ?>
<div class="box box-primary">
  <div class="box-header">
    <h3 class="box-title">APIs</h3>
    <?php if($api_keys->isEmpty()): ?>
      <a href="<?php echo e(url('/apikey/create')); ?>" class="btn btn-sm btn-flat btn-success pull-right">Trading Bot API Key</a>
    <?php else: ?>
      <a disabled href="<?php echo e(url('/apikey/create')); ?>" class="btn btn-sm btn-flat btn-success pull-right">Trading Bot API Key</a>
    <?php endif; ?>
  </div>
  <div class="box-body table-responsive no-padding">
    <table class="table table-bordered table-striped">
      <thead>
        <tr>
          <th>API Name</th>
          <th>API Type</th>
          <th>API Key</th>
          <th>Deal Count</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $api_keys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $api_key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($api_key['name']); ?></td>
            <td>3commas.io</td>
            <td><?php echo e($api_key['api_key']); ?></td>
            <td><?php echo e($api_key['deal_count']); ?></td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>