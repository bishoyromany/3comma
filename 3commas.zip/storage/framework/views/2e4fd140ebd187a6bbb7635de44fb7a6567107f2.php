<?php $__env->startSection('content'); ?>
<div class="row">

    <div class="col-md-3 col-sm-6 col-xs-12">
      <div class="info-box">
        <span class="info-box-icon bg-green"><i class="fa fa-database"></i></span>
        <div class="info-box-content">
          <span class="info-box-text">Total<br>Deals</span>
          <span id="completed_deals" class="info-box-number"><?php echo e($completed_deals > 0 ? number_format($completed_deals) : '0'); ?></span>
        </div>
      </div>
    </div>

    <div class="col-md-3 col-sm-6 col-xs-12">
      <div class="info-box">
        <span class="info-box-icon bg-green"><i class="fa fa-bolt"></i></span>
        <div class="info-box-content">
          <span class="info-box-text">Active<br>Deals</span>
          <span id="active_deals"  class="info-box-number"><?php echo e($active_deals > 0 ? number_format($active_deals) : '0'); ?></span>
        </div>
      </div>
    </div>

    <div class="col-md-3 col-sm-6 col-xs-12">
      <div class="info-box">
        <span class="info-box-icon bg-green"><i class="fa fa-rocket"></i></span>
        <div class="info-box-content">
          <span class="info-box-text">Total<br>Bots</span>
          <span id="bot_count" class="info-box-number"><?php echo e($bot_count > 0 ? number_format($bot_count) : '0'); ?></span>
        </div>
      </div>
    </div>

    <div class="col-md-3 col-sm-6 col-xs-12">
      <div class="info-box">
        <span class="info-box-icon bg-green"><i class="fa fa-exclamation-triangle"></i></span>
        <div class="info-box-content">
          <span class="info-box-text">Active<br>Bots</span>
          <span id="active_bots" class="info-box-number"><?php echo e($active_bots > 0 ? number_format($active_bots) : '0'); ?></span>
        </div>
      </div>
    </div>
</div>

<div class="row">
  <div class="col-sm-12 col-md-12">
    <div class="box box-primary">
      <div class="box-header">
        <h3 class="box-title">Total Profits</h3>
      </div>
      <div class="box-body table-responsive no-padding">
        <table id="tbl_dashboard" class="table table-bordered table-striped table-hover-blue">
          <thead>
            <tr>
              <th>Currency</th>
              <th>Profit</th>
              <th>Pairs</th>
              <th>Completed</th>
              <th>Panics</th>
              <th>Stops</th>
              <th>Switched</th>
              <th>Failed</th>
              <th>Cancelled</th>
              <th style="background-color: #3c8dbc30; font-weight: bold;">Deals</th>
            </tr>
          </thead>
          <tbody>
          <?php if($completed_deals > 0): ?>
            <?php $__currentLoopData = $base_profit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $total): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if($total->base === ''): ?>
              <tr style="background-color: #3c8dbc30; font-weight: bold;">
                <?php else: ?>
                <tr>
                  <?php endif; ?>
                <td>
                  <?php if($total->base != ''): ?>
                    <img src="<?php echo e(asset('img/coins/' . strtolower($total->base) . '.png')); ?>" height="22px"> <span class="label bg-gray"><?php echo e($total->base); ?></span>
                  <?php else: ?>
                    Total
                  <?php endif; ?>
                </td>
                <td><span style="font-weight: bold;"><?php echo e($total->profit); ?></span></td>
                <td><?php echo e($total->unique); ?></td>
                <td><?php echo e($total->completed); ?></td>
                <td><?php echo e($total->panic); ?></td>
                <td><?php echo e($total->stop); ?></td>
                <td><?php echo e($total->switched); ?></td>
                <td><?php echo e($total->failed); ?></td>
                <td><?php echo e($total->cancelled); ?></td>
                <td style="background-color: #3c8dbc30; font-weight: bold;"><?php echo e($total->actual); ?></td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php else: ?>
          <tr>
            <td colspan="47">No Data Available</td>
          </tr>
          <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<div class="row">
  <div class="col-sm-12 col-md-12">
    <div class="box box-warning">
      <div class="box-header">
        <div class="pull-right">
          Cancel All | Panic Sell All
        </div>
        <h3 class="box-title">Active Deals</h3>
      </div>
      <div class="box-body table-responsive no-padding">
        <table class="table table-bordered table-striped table-hover-blue">
            <thead><tr>
            <th>ID / Bot</th>
            <th>Pair</th>
            <th>BO</th>
            <th>SO</th>
            <th>SOS</th>
            <th>MC</th>
            <th colspan="3">Safety Trades</th>
            <th>TP</th>
            <th>C PS</th>
            </tr></thead>
          <tbody>
          <?php if(count($active_deals_list) > 1): ?>
            <?php $__currentLoopData = $active_deals_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td><a href="<?php echo e(route('basic.deal.show', $ad->id )); ?>" class="label label-primary" title="Show Deal"><?php echo e($ad->id); ?></a><br>
                  <a href="<?php echo e(route('basic.bot.show', $ad->bot_id )); ?>" class="label label-primary" title="Show Bot"><?php echo e($ad->bot_name); ?></a></td>
                <td><?php echo e($ad->pair); ?></td>
                <td><?php echo e($ad->base_order_volume); ?></td>
                <td><?php echo e($ad->safety_order_volume); ?></td>
                <td><?php echo e($ad->safety_order_step_percentage); ?></td>
                <td><?php echo e($ad->martingale_coefficient); ?></td>
                <td><?php echo e($ad->completed_safety_orders_count); ?></td>
                <td><?php echo e($ad->active_safety_orders_count); ?></td>
                <td><?php echo e($ad->max_safety_orders); ?></td>
                <td><?php echo e($ad->take_profit); ?>%</td>
                <td>C PS</td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php else: ?>
          <tr>
            <td colspan="47">No Data Available</td>
          </tr>
          <?php endif; ?>
        </tbody></table>
      </div>
    </div>
  </div>
</div>

<div class="row">
  <div class="col-sm-12 col-md-12">
    <div class="box box-warning">
      <div class="box-header">
        <h3 class="box-title">Active Bots</h3>
      </div>
      <div class="box-body table-responsive no-padding">
        <table class="table table-bordered table-striped table-hover-blue">
            <thead><tr>
                <th>Name</th>
                <th>Strategy</th>
                <th>Pairs</th>
                <th>BO</th>
                <th>SO</th>
                <th>SOS%</th>
                <th>Vol</th>
                <th>SC</th>
                <th>SOC</th>
                <th>Max Safe</th>
                <th>Take Profit</th>
                <th>Completed USD</th>
                <th>ADP</th>
                <th>TUP</th>
                <th>MAD</th>
                <th>SL</th>
                <th>TPT</th>
                <th>ADC</th>
                <th>BOVT</th>
                <th>SOVT</th>
            </tr></thead>
          <tbody>
          <?php if(count($active_bots_list) > 1): ?>
            <?php $__currentLoopData = $active_bots_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $abl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td><a href="<?php echo e(route('basic.bot.show', $abl->id )); ?>" class="label label-primary" title="Show Bot"><?php echo e($abl->name); ?></a></td>
                <td><?php echo e($abl->strategy); ?></td> <!-- rewrite value to Single Long Short Multi,m etc-->
                <td><?php echo e($abl->pairs); ?></td>
                <td><?php echo e($abl->base_order_volume); ?></td>
                <td><?php echo e($abl->safety_order_volume); ?></td>
                <td><?php echo e($abl->safety_order_step_percentage); ?></td>
                <td><?php echo e($abl->martingale_volume_coefficient); ?></td>
                <td><?php echo e($abl->martingale_step_coefficient); ?></td>
                <td><?php echo e($abl->active_safety_orders_count); ?></td>
                <td><?php echo e($abl->max_safety_orders); ?></td>
                <td><?php echo e($abl->take_profit); ?>%</td>
                <td><?php echo e($abl->completed_deals_usd_profit); ?></td>
                <td><?php echo e($abl->active_deals_usd_profit); ?></td>
                <td><?php echo e($abl->total_usd_profit); ?></td>
                <td><?php echo e($abl->max_active_deals); ?></td>
                <td><?php echo e($abl->strategy_list); ?></td>
                <td><?php echo e($abl->take_profit_type); ?></td>
                <td><?php echo e($abl->active_deals_count); ?></td>
                <td><?php echo e($abl->base_order_volume_type); ?></td>
                <td><?php echo e($abl->safety_order_volume_type); ?></td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php else: ?>
          <tr>
            <td colspan="47">No Data Available</td>
          </tr>
          <?php endif; ?>
        </tbody></table>
      </div>
    </div>
  </div>
</div>

<div class="row">
  <div class="col-sm-12 col-md-12">
    <div class="box box-success">
      <div class="box-header">
        <h3 class="box-title">Recently Completed Deals</h3>
      </div>
      <div class="box-body table-responsive no-padding">
        <table class="table table-bordered table-striped table-hover-blue">
            <thead><tr>
                <th>ID / Bot</th>
                <th>Pair</th>
                <th>BO</th>
                <th>SO</th>
                <th>SOS</th>
                <th>MC</th>
                <th colspan="3">Safety Trades</th>
                <th>TP</th>
                <th>Final Profit</th>
            </tr></thead>
          <tbody>
          <?php if(count($recent_completed_deals) > 1): ?>
            <?php $__currentLoopData = $recent_completed_deals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td><a href="<?php echo e(route('basic.deal.show', $rd->id )); ?>" class="label label-primary" title="Show Deal"><?php echo e($rd->id); ?></a><br>
                  <a href="<?php echo e(route('basic.bot.show', $rd->bot_id )); ?>" class="label label-primary" title="Show Bot"><?php echo e($rd->bot_name); ?></a></td>
                <td><?php echo e($rd->pair); ?></td>
                <td><?php echo e($rd->base_order_volume); ?></td>
                <td><?php echo e($rd->safety_order_volume); ?></td>
                <td><?php echo e($rd->safety_order_step_percentage); ?></td>
                <td><?php echo e($rd->martingale_coefficient); ?></td>
                <td><?php echo e($rd->completed_safety_orders_count); ?></td>
                <td><?php echo e($rd->active_safety_orders_count); ?></td>
                <td><?php echo e($rd->max_safety_orders); ?></td>
                <td><?php echo e($rd->take_profit); ?>%</td>
                <td><?php echo e($rd->final_profit); ?></td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php else: ?>
          <tr>
            <td colspan="47">No Data Available</td>
          </tr>
          <?php endif; ?>
        </tbody></table>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
  <?php if(session()->has('load_deal')): ?>
    <script>
        function updateDashboard() {
            $.get('<?php echo e(route('dashboard/data')); ?>', function (response) {
                waitingDialog.hide();

                if (response.completed_deals > 0)
                    $('#completed_deals').text(response.completed_deals);
                else
                    $('#completed_deals').text('?');

                if (response.active_deals > 0)
                    $('#active_deals').text(response.active_deals);
                else
                    $('#active_deals').text('?');

                if (response.bot_count > 0)
                    $('#bot_count').text(response.bot_count);
                else
                    $('#bot_count').text('?');

                if (response.active_bots > 0)
                    $('#active_bots').text(response.active_bots);
                else
                    $('#active_bots').text('?');

                $('#tbl_dashboard tbody').empty();
                if (response.completed_deals > 0) {
                    response.base_profit.forEach(function (row, index) {
                        if (row.base == '')
                            tr = '<tr style="background-color: #3c8dbc30; font-weight: bold;">' +
                                '<td></td>';
                        else
                            tr = '<tr>' +
                                '<td><img src="<?php echo e(asset('img/coins/')); ?>/' + row.base.toLowerCase() + '.png" height="22px"> <span class="label bg-gray">' + row.base + '</span></td>';

                        tr += '<td><span style="font-weight: bold;">' + row.profit + '</span></td>' +
                            '<td>' + row.unique + '</td>' +
                            '<td>' + row.completed + '</td>' +
                            '<td>' + row.panic + '</td>' +
                            '<td>' + row.stop + '</td>' +
                            '<td>' + row.switched + '</td>' +
                            '<td>' + row.failed + '</td>' +
                            '<td>' + row.cancelled + '</td>' +
                            '<td style="background-color: #3c8dbc30; font-weight: bold;">' + row.actual + '</td>' +
                            '</tr>';

                        $('#tbl_dashboard tbody').append(tr);
                    });
                } else {
                    $('#tbl_dashboard tbody').append('<tr><td colspan="47">No Data Available</td></tr>');
                }
            });
        }

        /*
        waitingDialog.show('Please wait while downloading');
        var dealLoaded = false, botLoaded = false;
        $.get('<?php echo e(route('3commas/loadDeal')); ?>', function (response) {
            console.log(response);
            dealLoaded = true;
            if (dealLoaded && botLoaded)
                updateDashboard();
        });

        $.get('<?php echo e(route('3commas/loadBots')); ?>', function (response) {
            console.log(response);
            botLoaded = true;
            if (dealLoaded && botLoaded)
                updateDashboard();
        });
        */
    </script>
  <?php endif; ?>
    <script>
        /*
        $.post('<?php echo e(route ('3commas/panicSellDeal', ['deal_id' => 11503406])); ?>', {
            "_token" : "<?php echo e(csrf_token()); ?>"
        }, function (response) {
            console.log(response);
            updateDashboard();
        });
        $.post('<?php echo e(route ('3commas/cancelDeal', ['deal_id' => 11503406])); ?>', {
            "_token" : "<?php echo e(csrf_token()); ?>"
        }, function (response) {
            console.log(response);
            updateDashboard();
        });
        */
        /*
        $.post('<?php echo e(route ('3commas/disableBot', ['bot_id' => 97053])); ?>', {
            "_token" : "<?php echo e(csrf_token()); ?>"
        }, function (response) {
            console.log(response);
            updateDashboard();
        });
        $.post('<?php echo e(route ('3commas/enableBot', ['bot_id' => 34682])); ?>', {
            "_token" : "<?php echo e(csrf_token()); ?>"
        }, function (response) {
            console.log(response);
            updateDashboard();
        });
        $.post('<?php echo e(route ('3commas/startNewDeal', ['bot_id' => 34682])); ?>', {
            "_token" : "<?php echo e(csrf_token()); ?>"
        }, function (response) {
            console.log(response);
            updateDashboard();
        });
        */
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>