![picture](https://github.com/stachschwarz/3commas-bot/blob/master/public/img/logo-white-trans.png?raw=trues)

## About BotPump

Analyze, tweak, create, and understand your bots like never before. Tools, reports, insights, and data to refine your stategy to get the best performance from your cryptocurrency trading bots. 