<?php

return [
    'token' => 'a7gj4tq1piubcu9pxo2is8hciqdcmu',
    'user_key' => 'ufL74AmZgbjnJZiuJErmVvq94JwEQS',
];

?>
