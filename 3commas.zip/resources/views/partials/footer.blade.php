<footer class="main-footer">
    <!-- To the right -->
    <div class="pull-right hidden-xs">
        v0.2.1
    </div>
    <!-- Default to the left -->
    <strong><a href="#">BotPump.com © 2018</a>
</footer>