@extends('layouts.default')

@section('content')
    404 Page Not Found
@endsection