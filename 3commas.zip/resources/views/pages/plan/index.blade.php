@extends('layouts.default')

@section('content')
    Beta Testing Free Plan
@endsection